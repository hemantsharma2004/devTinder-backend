const express = require("express");
const connectdb = require("./config/database");
const cookieParser = require("cookie-parser");
const cors = require("cors");
require("dotenv").config();

const app = express();

// ✅ Middlewares
app.use(express.json());
app.use(cookieParser());

const allowedOrigins = [
  "https://dev-tinder-navy.vercel.app",
  "http://localhost:5173"
];

// ✅ CORS config
app.use(cors({
  origin: allowedOrigins,
  credentials: true
}));

// ✅ Preflight (optional for older browsers)
app.options("*", cors({
  origin: allowedOrigins,
  credentials: true
}));

// ✅ Test route
app.get("/", (req, res) => {
  res.send("Hello World");
});

// ✅ Routes
const authRouter = require("./routes/auth");
const profileRouter = require("./routes/profile");
const requestRouter = require("./routes/request");
const userRouter = require("./routes/user");

app.use("/", authRouter);
app.use("/", profileRouter);
app.use("/", requestRouter);
app.use("/", userRouter);

// ✅ Error handler
app.use((err, req, res, next) => {
  console.error("Global Error:", err);
  res.status(500).json({ error: err.message });
});

// ✅ Start server
connectdb()
  .then(() => {
    console.log("Database connected successfully");
    app.listen(process.env.PORT, () => {
      console.log(`Server running on port ${process.env.PORT}`);
    });
  })
  .catch((err) => {
    console.error("Database connection failed:", err);
  });
